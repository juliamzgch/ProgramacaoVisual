﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T02_JuliaMizuguchi
{
    enum Season2_JM : byte
    {
        Spring, Summer, Fall, Autumn = Fall, Winter
    }
}
