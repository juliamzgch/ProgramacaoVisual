﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T02_JuliaMizuguchi
{
    enum Season3_JM : long
    {
        Spring = 5, Summer, Fall, Winter
    }
}
