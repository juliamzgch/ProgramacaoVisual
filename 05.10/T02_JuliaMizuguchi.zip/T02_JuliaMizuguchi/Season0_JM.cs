﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T02_JuliaMizuguchi
{
    // por omissão: tipo subjacente é int começa em 0
    enum Season0_JM
    {
        Spring, Summer, Fall, Winter
    };
}
