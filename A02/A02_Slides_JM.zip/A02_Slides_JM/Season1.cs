﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A02_Slides_JM
{
    // por omissão: tipo subjacente é int começa em 0
    enum Season1
    {
        Spring = 3, Summer, Fall, Winter
    };
}
