﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJETO_LAB03_2025116155_2025116166
{
    public enum Cor_JMJL
    {
        Branco_JMJL, Preto_JMJL
    }
}
