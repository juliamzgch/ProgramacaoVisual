﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJETO_LAB03_2025116155_2025116166
{
    internal interface IMover_JMJL 
    {

        public void Deslocar_JMJL(int dx_JMJL, int dy_JMJL);
        
    }
}
